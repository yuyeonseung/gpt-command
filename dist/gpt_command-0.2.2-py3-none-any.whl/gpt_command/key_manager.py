import argparse
import getpass
import os
import shlex
import subprocess
from pathlib import Path
from typing import Optional, Tuple

from .config import CONFIG_FILE, get_api_key, load_config, save_config, set_default_model

CONFIG_MARKER = "gptc shell integration"


def detect_shell() -> Tuple[Optional[str], Optional[Path]]:
    shell_path = os.environ.get("SHELL", "").strip()
    shell_name = Path(shell_path).name if shell_path else ""

    if shell_name == "zsh":
        return "zsh", Path.home() / ".zshrc"
    if shell_name == "bash":
        return "bash", Path.home() / ".bashrc"

    return None, None

def get_integration_block(shell_name: str) -> str:
    if shell_name == "zsh":
        return f"""
# >>> {CONFIG_MARKER} >>>
gptc() {{
  local arg

  for arg in "$@"; do
    if [[ "$arg" == --* ]]; then
      gptc-gen "$@"
      return $?
    fi
  done

  local cmd
  cmd="$(GPTC_CAPTURE_MODE=1 gptc-gen "$@")" || return $?
  [[ -z "$cmd" ]] && return 0
  print -z -- "$cmd"
}}
# <<< {CONFIG_MARKER} <<<
""".lstrip()

    if shell_name == "bash":
        return f"""
# >>> {CONFIG_MARKER} >>>
gptc() {{
  local arg

  for arg in "$@"; do
    if [[ "$arg" == --* ]]; then
      gptc-gen "$@"
      return $?
    fi
  done

  local cmd
  cmd="$(GPTC_CAPTURE_MODE=1 gptc-gen "$@")" || return $?
  [[ -z "$cmd" ]] && return 0
  history -s -- "$cmd"
  printf '%s\\n' "$cmd"
}}
# <<< {CONFIG_MARKER} <<<
""".lstrip()

    raise ValueError(f"Unsupported shell: {shell_name}")


def is_integration_installed(rc_file: Path) -> bool:
    if not rc_file.exists():
        return False

    try:
        content = rc_file.read_text(encoding="utf-8")
    except Exception:
        return False

    return CONFIG_MARKER in content


def install_shell_integration() -> bool:
    shell_name, rc_file = detect_shell()

    if not shell_name or not rc_file:
        print("Unsupported shell. Only zsh and bash are supported for automatic integration.")
        return False

    if not rc_file.exists():
        rc_file.touch()

    if is_integration_installed(rc_file):
        print(f"Shell integration already installed in {rc_file}. Skipping.")
        return False

    block = get_integration_block(shell_name)

    with open(rc_file, "a", encoding="utf-8") as f:
        f.write("\n" + block + "\n")

    print(f"Shell integration installed into {rc_file}.")
    attempt_reload_shell(shell_name, rc_file)
    return True


def attempt_reload_shell(shell_name: str, rc_file: Path) -> None:
    """
    A child process cannot reload the current parent shell session.
    This only attempts to source the rc file in a subshell so syntax errors can be caught.
    """
    source_cmd = f"source {shlex.quote(str(rc_file))}"

    try:
        result = subprocess.run(
            [shell_name, "-ic", source_cmd],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False,
        )
        if result.returncode == 0:
            print("Shell reload check completed.")
        else:
            print("Shell reload check failed. You may need to reload your shell manually.")
    except Exception:
        print("Automatic shell reload check could not be performed.")

    print(f"To apply it in your current shell, run: source {rc_file}")


def set_api_key() -> None:
    print("Enter your OpenAI API key. Input will be hidden.")
    key = getpass.getpass("API Key: ").strip()

    if not key:
        print("No key entered.")
        return

    config = load_config()
    config["OPENAI_API_KEY"] = key
    save_config(config)

    print(f"API key saved to {CONFIG_FILE}")
    install_shell_integration()


def delete_api_key() -> None:
    config = load_config()
    if "OPENAI_API_KEY" in config:
        del config["OPENAI_API_KEY"]
        save_config(config)
        print("Stored API key deleted.")
    else:
        print("No stored API key found.")


def show_status() -> None:
    key = get_api_key()
    if key:
        masked = key[:7] + "*" * max(0, len(key) - 11) + key[-4:]
        print("API key is configured.")
        print(f"Key preview: {masked}")
    else:
        print("API key is not configured.")

    config = load_config()
    model = config.get("DEFAULT_MODEL", "gpt-5.4-nano")
    print(f"Default model: {model}")

    shell_name, rc_file = detect_shell()
    if shell_name and rc_file:
        status = "installed" if is_integration_installed(rc_file) else "not installed"
        print(f"Detected shell: {shell_name}")
        print(f"RC file: {rc_file}")
        print(f"Shell integration: {status}")
    else:
        print("Detected shell: unsupported")


def set_model(model: str) -> None:
    set_default_model(model)
    print(f"Default model saved: {model}")


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="gptc-key",
        description="Manage gptc API key and shell integration.",
    )
    parser.add_argument("--set", action="store_true", help="Set the API key.")
    parser.add_argument("--delete", action="store_true", help="Delete the stored API key.")
    parser.add_argument("--status", action="store_true", help="Show current status.")
    parser.add_argument("--model", type=str, help="Set the default model.")

    args = parser.parse_args()
    acted = False

    if args.set:
        set_api_key()
        acted = True

    if args.delete:
        delete_api_key()
        acted = True

    if args.status:
        show_status()
        acted = True

    if args.model:
        set_model(args.model)
        acted = True

    if not acted:
        set_api_key()