# gpt-command (gptc)

> Turn natural language into ready-to-use terminal commands.

`gptc` is a lightweight CLI tool that converts plain English (or any language) into executable shell commands for macOS and Linux.

---

## 🚀 Installation

```bash
pip install gpt-command
```

---

🔑 Setup (Required)

Run once to configure your API key and enable shell integration::

```bash
gptc-key
```
This will:

- Store your OpenAI API key securely
- Automatically install shell integration (zsh or bash)
- Detect your current shell and update the correct rc file

After setup, apply changes:
```bash
source ~/.zshrc
# or
source ~/.bashrc
```

Check status:

```bash
gptc-key --status
```
Set default model (optional):

```bash
gptc-key --model gpt-5.4-nano
```

---

💡 Usage
```bash
gptc <your question>
```
Example
```bash
gptc find and delete all txt files in current directory recursively
```
Output:
```bash
find . -type f -name "*.txt" -delete
```
Then it will automatically prefill your terminal input:

```bash
~/current/path$ find . -type f -name "*.txt" -delete
```
⚠️ The command is NOT executed automatically.

---

⚙️ Options

📋 Copy to clipboard

```bash
gptc --copy compress current folder into tar.gz
```
📖 Show explanation

```bash
gptc --explain find process using port 8000
```
▶️ Execute command (with confirmation)

```bash
gptc --run check disk usage
```
🧠 Show history

```bash
gptc --history
```
🤖 Specify model

```bash
gptc --model gpt-4.1 list all running processes
```

---

🔐 Security

- API key is stored locally at:

```bash
~/.config/gptc/config.json
```
File permissions are restricted to the user (600)
Dangerous commands are automatically detected and blocked from execution

---

⚠️ Disclaimer
- Always review generated commands before running them
- Some commands may modify or delete system data
- Use with caution, especially with elevated privileges (sudo)

---

🖥️ Supported Platforms

- macOS
- Linux (Ubuntu, etc.)

---

✨ Features
- Natural language → shell command
- Auto-prefilled terminal input (no copy-paste needed)
- Optional execution with confirmation
- Clipboard copy support
- Command explanation
- History tracking
- Local API key management (no environment variable required)

---

📌 Summary

> Stop Googling terminal commands. Just ask.

---

📄 License

MIT License